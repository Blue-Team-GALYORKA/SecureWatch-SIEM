"""Тесты конвейера SIEM. Запуск:  python -m unittest discover -s tests -v"""

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from siem.config import Settings  # noqa: E402
from siem.knowledge import KnowledgeBase  # noqa: E402
from siem.pipeline import Pipeline  # noqa: E402
from siem.services.aggregator import Aggregator  # noqa: E402
from siem.services.correlation import match_filter  # noqa: E402
from siem.services.normalization import Normalizer  # noqa: E402
from siem.storage import Storage  # noqa: E402


def make_pipeline(window=5):
    settings = Settings()
    settings.aggregation_window = window
    return Pipeline(settings, Storage(":memory:"))


def ssh_fail(sec, user="admin", ip="203.0.113.10", host="web01"):
    return f"Nov 24 15:00:{sec:02d} {host} sshd[{100 + sec}]: Failed password for {user} from {ip} port 40{sec:02d} ssh2"


def incidents(pipeline):
    return {i["rule_id"]: i for i in pipeline.storage.query("SELECT * FROM incidents")}


class NormalizationTests(unittest.TestCase):
    def setUp(self):
        self.n = Normalizer("Europe/Moscow")

    def test_ssh_failure(self):
        e = self.n.normalize({"line": ssh_fail(1, "bob")})
        self.assertEqual((e["category"], e["action"], e["status"]), ("auth", "login", "failure"))
        self.assertEqual((e["subject_user"], e["src_ip"], e["host"]), ("bob", "203.0.113.10", "web01"))
        self.assertTrue(e["time"].endswith("+00:00"))

    def test_rfc5424_and_priority(self):
        e = self.n.normalize({"line": "<38>1 2026-11-24T15:00:00+03:00 srv1 sshd 77 - - Accepted publickey for alice from 10.0.0.5 port 2222 ssh2"})
        self.assertEqual((e["status"], e["subject_user"], e["host"]), ("success", "alice", "srv1"))
        self.assertEqual(e["time"], "2026-11-24T12:00:00+00:00")

    def test_windows_json(self):
        e = self.n.normalize({"line": json.dumps({"EventID": 4625, "Computer": "PC-7", "TargetUserName": "ivan",
                                                  "IpAddress": "10.1.1.9", "TimeCreated": "2026-11-24T10:00:00Z"})})
        self.assertEqual((e["format"], e["status"], e["host"], e["src_ip"]), ("windows", "failure", "PC-7", "10.1.1.9"))

    def test_access_log_sqli(self):
        e = self.n.normalize({"line": '198.51.100.7 - - [24/Nov/2026:15:10:00 +0300] "GET /?id=1%27%20OR%20%271%27=%271 HTTP/1.1" 200 5 "-" "curl"'})
        self.assertEqual((e["category"], e["action"], e.get("attack")), ("web", "attack_attempt", "sqli"))

    def test_unknown_line_kept(self):
        e = self.n.normalize({"line": "какая-то строка", "host": "h"})
        self.assertEqual((e["format"], e["category"]), ("raw", "other"))
        self.assertEqual(self.n.stats["unparsed"], 1)


class AggregatorTests(unittest.TestCase):
    def test_identical_events_glued(self):
        clock = [0.0]
        agg = Aggregator(5, clock=lambda: clock[0])
        n = Normalizer()
        line = "Nov 24 15:00:00 h cron[1]: job done"
        for _ in range(3):
            self.assertEqual(agg.add(n.normalize({"line": line})), [])
        self.assertEqual(agg.flush(), [])
        clock[0] = 6
        out = agg.flush()
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0]["count"], 3)
        self.assertIn("aggregated", out[0]["tags"])


class FilterTests(unittest.TestCase):
    def test_operators(self):
        event = {"status": "failure", "tags": ["ioc", "off_hours"], "http_status": 404, "object": "/bin/nc -e"}
        self.assertTrue(match_filter({"status": "failure", "tags": "ioc"}, event))
        self.assertTrue(match_filter({"http_status": {"gte": 400}}, event))
        self.assertTrue(match_filter({"object": {"regex": r"\bnc\b"}}, event))
        self.assertFalse(match_filter({"status": ["success"]}, event))
        self.assertFalse(match_filter({"subject_user": {"exists": True}}, event))


class CorrelationTests(unittest.TestCase):
    def test_bruteforce_then_success(self):
        p = make_pipeline()
        lines = [ssh_fail(i) for i in range(6)]
        lines.append("Nov 24 15:00:30 web01 sshd[300]: Accepted password for admin from 203.0.113.10 port 5000 ssh2")
        p.receiver.accept(lines, host="web01")
        p.drain()
        found = incidents(p)
        self.assertIn("SW-AUTH-001", found)
        self.assertIn("SW-AUTH-002", found)
        self.assertEqual(found["SW-AUTH-002"]["severity"], "critical")
        self.assertIn("SW-AUTH-004", found)  # admin вошёл с внешнего адреса

    def test_password_spraying(self):
        p = make_pipeline()
        p.receiver.accept([ssh_fail(i, user=f"user{i}") for i in range(5)])
        p.drain()
        self.assertIn("SW-AUTH-003", incidents(p))

    def test_incident_deduplication(self):
        p = make_pipeline(window=0)
        p.receiver.accept([ssh_fail(i) for i in range(15)])
        p.drain()
        rows = p.storage.query("SELECT * FROM incidents WHERE rule_id='SW-AUTH-001'")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["event_count"], 15)

    def test_new_admin_user(self):
        p = make_pipeline()
        p.receiver.accept([
            "Nov 24 15:08:00 web01 useradd[300]: new user: name=hacker, UID=1001, GID=1001",
            "Nov 24 15:08:10 web01 usermod[301]: add 'hacker' to group 'sudo'",
            "Nov 24 15:09:00 web01 sudo:   hacker : TTY=pts/0 ; PWD=/root ; USER=root ; COMMAND=/bin/cat /etc/shadow",
        ])
        p.drain()
        found = incidents(p)
        for rule in ("SW-ACC-001", "SW-ACC-002", "SW-ACC-003", "SW-PROC-001"):
            self.assertIn(rule, found)

    def test_ioc_enrichment(self):
        p = make_pipeline()
        p.receiver.accept(["Nov 24 15:00:00 web01 sshd[1]: Accepted publickey for bob from 203.0.113.66 port 1 ssh2"])
        p.drain()
        event = p.storage.search_events()[0][0]
        self.assertIn("ioc", event["tags"])
        self.assertIn("external_src", event["tags"])
        self.assertIn("SW-TI-001", incidents(p))

    def test_internal_address_not_external(self):
        p = make_pipeline()
        p.receiver.accept(["Nov 24 15:00:00 web01 sshd[1]: Accepted publickey for bob from 192.168.1.20 port 1 ssh2"])
        p.drain()
        self.assertIn("internal_src", p.storage.search_events()[0][0]["tags"])


class KnowledgeTests(unittest.TestCase):
    def test_bundled_rules_are_valid(self):
        kb = KnowledgeBase(Path(__file__).resolve().parent.parent / "knowledge")
        self.assertEqual(kb.errors, [])
        self.assertGreaterEqual(len(kb.rules), 10)

    def test_broken_rule_reported(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "rules").mkdir()
            (Path(tmp) / "ioc").mkdir()
            (Path(tmp) / "rules" / "bad.yaml").write_text("- {id: X, name: x, type: magic, severity: high}\n", encoding="utf-8")
            kb = KnowledgeBase(tmp)
            self.assertEqual(kb.rules, [])
            self.assertEqual(len(kb.errors), 1)


if __name__ == "__main__":
    unittest.main()
