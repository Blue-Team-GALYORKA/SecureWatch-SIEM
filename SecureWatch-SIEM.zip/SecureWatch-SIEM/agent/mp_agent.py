#!/usr/bin/env python3
"""MP agent для SecureWatch SIEM — сборщик логов на хосте (только стандартная библиотека Python).

Агент читает новые строки из указанных журналов и отправляет их пачками в Receiver.S:

    python3 mp_agent.py --server http://siem.local:8080 --token swa_... \
        --file /var/log/auth.log --file /var/log/nginx/access.log:access

Формат после двоеточия необязателен (syslog | access | json | windows) — по умолчанию
SIEM определит его сам. Позиции чтения сохраняются в файле состояния, поэтому после
перезапуска агент продолжит с того же места и корректно переживёт ротацию журнала.
"""

import argparse
import ipaddress
import json
import os
import platform
import socket
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

STATE_PATH = Path.home() / ".securewatch-siem-agent.json"
BATCH_SIZE = 500
MAX_LINE = 8192
FORMATS = {"syslog", "access", "json", "windows"}


def host_info():
    system = platform.system() or "Unknown"
    os_name = f"{system} {platform.release()}".strip()
    if system == "Linux":
        try:
            os_name = platform.freedesktop_os_release().get("PRETTY_NAME") or os_name
        except (AttributeError, OSError):
            pass
    ips = set()
    try:
        for result in socket.getaddrinfo(socket.gethostname(), None):
            try:
                ip = ipaddress.ip_address(result[4][0].split("%", 1)[0])
            except ValueError:
                continue
            if not (ip.is_loopback or ip.is_unspecified or ip.is_multicast):
                ips.add(str(ip))
    except OSError:
        pass
    return {"os": os_name[:100], "ips": sorted(ips)[:16]}


def validate_server(value):
    parsed = urllib.parse.urlsplit(value.strip())
    if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.path not in {"", "/"}:
        raise argparse.ArgumentTypeError("сервер указывается как http(s)://адрес[:порт]")
    return f"{parsed.scheme}://{parsed.netloc}"


class FileTail:
    def __init__(self, path, fmt, state, from_start):
        self.path, self.fmt = Path(path), fmt
        saved = state.get(str(self.path), {})
        self.inode = saved.get("inode")
        self.offset = saved.get("offset")
        self.from_start = from_start

    def read(self, limit):
        try:
            st = self.path.stat()
        except OSError:
            return []
        if self.offset is None:  # первый запуск: читаем только новое, если не попросили иначе
            self.offset = 0 if self.from_start else st.st_size
            self.inode = st.st_ino
        if st.st_ino != self.inode or st.st_size < self.offset:  # ротация или усечение
            self.inode, self.offset = st.st_ino, 0
        records = []
        try:
            with open(self.path, "rb") as fh:
                fh.seek(self.offset)
                while len(records) < limit:
                    raw = fh.readline()
                    if not raw or not raw.endswith(b"\n"):  # неполную строку дочитаем позже
                        break
                    line = raw.decode("utf-8", errors="replace").rstrip("\r\n")[:MAX_LINE]
                    if line.strip():
                        records.append({"line": line, "file": str(self.path), "format": self.fmt,
                                        "_offset": fh.tell()})
        except OSError as exc:
            print(f"[agent] не могу прочитать {self.path}: {exc}", file=sys.stderr)
        return records

    def commit(self, offset):
        self.offset = offset

    def state(self):
        return {"inode": self.inode, "offset": self.offset}


def send(server, token, hostname, records, info, insecure=False):
    payload = {
        "host": hostname,
        "agent_info": info,
        "records": [{k: v for k, v in r.items() if not k.startswith("_")} for r in records],
    }
    request = urllib.request.Request(
        f"{server}/api/v1/ingest",
        data=json.dumps(payload).encode(),
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json",
                 "User-Agent": "securewatch-mp-agent/1.0"},
        method="POST",
    )
    context = None
    if insecure:
        import ssl
        context = ssl._create_unverified_context()  # только для стенда с самоподписанным сертификатом
    with urllib.request.urlopen(request, timeout=15, context=context) as response:
        return json.loads(response.read() or b"{}").get("accepted", 0)


def main():
    parser = argparse.ArgumentParser(description="SecureWatch SIEM MP agent")
    parser.add_argument("--server", type=validate_server, required=True)
    parser.add_argument("--token", default=os.getenv("SIEM_AGENT_TOKEN"), help="или переменная SIEM_AGENT_TOKEN")
    parser.add_argument("--file", action="append", required=True, help="путь[:формат], можно несколько раз")
    parser.add_argument("--hostname", default=socket.gethostname())
    parser.add_argument("--interval", type=float, default=2.0, help="пауза между опросами, сек")
    parser.add_argument("--from-start", action="store_true", help="при первом запуске прочитать файлы целиком")
    parser.add_argument("--once", action="store_true", help="отправить накопленное и выйти")
    parser.add_argument("--state", type=Path, default=STATE_PATH)
    parser.add_argument("--insecure", action="store_true", help="не проверять TLS-сертификат (стенд)")
    args = parser.parse_args()
    if not args.token:
        parser.error("нужен --token или SIEM_AGENT_TOKEN")

    try:
        state = json.loads(args.state.read_text())
    except (OSError, ValueError):
        state = {}

    tails = []
    for spec in args.file:
        path, fmt = spec, None
        head, _, tail_fmt = spec.rpartition(":")
        if head and tail_fmt in FORMATS:  # «/var/log/x.log:access»; путь вида C:\... не ломается
            path, fmt = head, tail_fmt
        tails.append(FileTail(path, fmt, state, args.from_start))

    info = host_info()
    print(f"[agent] {args.hostname} → {args.server}, файлов: {len(tails)}")
    backoff = args.interval
    while True:
        sent_any = False
        for tail in tails:
            records = tail.read(BATCH_SIZE)
            if not records:
                continue
            try:
                accepted = send(args.server, args.token, args.hostname, records, info, args.insecure)
                tail.commit(records[-1]["_offset"])
                sent_any = True
                backoff = args.interval
                print(f"[agent] {tail.path}: отправлено {accepted}")
            except urllib.error.HTTPError as exc:
                print(f"[agent] сервер ответил {exc.code}: {exc.read()[:200]!r}", file=sys.stderr)
                if exc.code in (401, 403):
                    sys.exit(2)
                backoff = min(backoff * 2, 60)
            except (urllib.error.URLError, OSError) as exc:
                print(f"[agent] нет связи с SIEM: {exc}", file=sys.stderr)
                backoff = min(backoff * 2, 60)
        try:
            args.state.write_text(json.dumps({str(t.path): t.state() for t in tails}))
        except OSError:
            pass
        if args.once and not sent_any:
            break
        if not sent_any:
            time.sleep(backoff)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
