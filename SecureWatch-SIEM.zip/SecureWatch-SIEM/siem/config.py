"""Настройки SecureWatch SIEM. Все значения берутся из переменных окружения (.env)."""

import os
from dataclasses import dataclass, field
from pathlib import Path

try:
    from dotenv import load_dotenv  # необязательная зависимость
    load_dotenv()
except ImportError:  # pragma: no cover
    pass

BASE_DIR = Path(__file__).resolve().parent.parent


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except ValueError:
        return default


def _bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass
class Settings:
    secret_key: str = field(default_factory=lambda: os.getenv("SECRET_KEY", ""))
    admin_user: str = field(default_factory=lambda: os.getenv("SIEM_ADMIN_USER", "admin"))
    admin_password: str = field(default_factory=lambda: os.getenv("SIEM_ADMIN_PASSWORD", ""))
    database_path: Path = field(default_factory=lambda: Path(os.getenv("SIEM_DATABASE", BASE_DIR / "data" / "siem.db")))
    knowledge_dir: Path = field(default_factory=lambda: Path(os.getenv("SIEM_KNOWLEDGE_DIR", BASE_DIR / "knowledge")))
    timezone: str = field(default_factory=lambda: os.getenv("SIEM_TIMEZONE", "Europe/Moscow"))
    aggregation_window: int = field(default_factory=lambda: _int("SIEM_AGGREGATION_WINDOW", 5))
    retention_days: int = field(default_factory=lambda: _int("SIEM_RETENTION_DAYS", 30))
    syslog_port: int = field(default_factory=lambda: _int("SIEM_SYSLOG_PORT", 0))
    cookie_secure: bool = field(default_factory=lambda: _bool("COOKIE_SECURE", False))
    work_hours: tuple = (8, 20)  # всё вне этого интервала помечается тегом off_hours


settings = Settings()
