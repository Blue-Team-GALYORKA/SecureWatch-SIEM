"""Receiver.S — «принять логи/подключения».

Принимает пачки сырых записей от агентов MP (HTTP API) и от syslog-источников (UDP),
проверяет размеры и ставит записи в очередь конвейера. Сам ничего не парсит —
это работа Normalization.S.
"""

import queue

from ..storage import iso, utcnow

MAX_BATCH = 1000
MAX_LINE = 8192


class Receiver:
    def __init__(self, maxsize: int = 100_000):
        self.queue = queue.Queue(maxsize=maxsize)
        self.stats = {"accepted": 0, "rejected": 0}

    def accept(self, records, *, host=None, source="agent"):
        """records — список строк или словарей {"line", "file", "format"}. Возвращает число принятых."""
        if not isinstance(records, list):
            raise ValueError("records must be a list")
        if len(records) > MAX_BATCH:
            raise ValueError(f"too many records in one batch (max {MAX_BATCH})")
        received_at = iso(utcnow())
        accepted = 0
        for item in records:
            if isinstance(item, str):
                item = {"line": item}
            if not isinstance(item, dict) or not isinstance(item.get("line"), str):
                self.stats["rejected"] += 1
                continue
            line = item["line"][:MAX_LINE]
            if not line.strip():
                continue
            record = {
                "line": line,
                "file": str(item.get("file") or "")[:256] or None,
                "format": str(item.get("format") or "")[:32] or None,
                "host": (str(item.get("host") or host or "")[:100]) or None,
                "source": source,
                "received_at": received_at,
            }
            try:
                self.queue.put_nowait(record)
            except queue.Full:
                self.stats["rejected"] += 1
                raise OverflowError("pipeline queue is full, retry later")
            accepted += 1
        self.stats["accepted"] += accepted
        return accepted
