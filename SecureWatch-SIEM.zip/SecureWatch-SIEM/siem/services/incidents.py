"""Инциденты — на схеме «сообщ. об инциденте».

Срабатывание правила корреляции превращается в инцидент. Повторные срабатывания того же
правила по той же группе (например, тот же IP атакующего), пока инцидент открыт,
не плодят новые карточки, а дописываются в существующую.
"""

from collections import defaultdict

from ..storage import Storage, iso, utcnow

STATUSES = ("new", "in_progress", "resolved", "false_positive")
STATUS_LABELS = {
    "new": "Новый",
    "in_progress": "В работе",
    "resolved": "Решён",
    "false_positive": "Ложное срабатывание",
}
SEVERITY_ORDER = {"low": 1, "medium": 2, "high": 3, "critical": 4}


class IncidentManager:
    def __init__(self, storage: Storage, notifier=None):
        self.storage = storage
        self.notifier = notifier  # необязательный колбэк: notifier(incident_dict, is_new)
        self.stats = {"created": 0, "updated": 0}

    @staticmethod
    def _title(alert):
        rule, event = alert["rule"], alert["event"]
        values = defaultdict(lambda: "?", {k: v for k, v in event.items() if isinstance(v, (str, int))})
        values.update({k: v for k, v in alert["group"].items() if v is not None})
        values["count"] = alert["count"]
        template = rule.get("title") or rule["name"]
        try:
            return template.format_map(values)[:200]
        except (ValueError, IndexError):
            return rule["name"][:200]

    def handle(self, alert):
        rule, event = alert["rule"], alert["event"]
        now = iso(utcnow())
        existing = self.storage.query_one(
            "SELECT * FROM incidents WHERE rule_id=? AND group_key=? AND status IN ('new','in_progress') "
            "ORDER BY id DESC LIMIT 1",
            (rule["id"], alert["group_key"]),
        )
        if existing and alert["group"]:
            incident_id = existing["id"]
            self.storage.execute(
                "UPDATE incidents SET event_count = event_count + ?, last_seen = MAX(last_seen, ?), updated_at=? "
                "WHERE id=?",
                (alert["count"], alert["last_seen"], now, incident_id),
            )
            is_new = False
            self.stats["updated"] += 1
        else:
            incident_id = self.storage.execute(
                "INSERT INTO incidents (rule_id, title, severity, group_key, host, src_ip, subject_user, "
                "description, mitre, event_count, first_seen, last_seen, created_at, updated_at) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    rule["id"], self._title(alert), rule["severity"], alert["group_key"],
                    alert["group"].get("host") or event.get("host"),
                    alert["group"].get("src_ip") or event.get("src_ip"),
                    alert["group"].get("subject_user") or event.get("subject_user"),
                    (rule.get("description") or "").strip(), rule.get("mitre"),
                    alert["count"], alert["first_seen"], alert["last_seen"], now, now,
                ),
            )
            is_new = True
            self.stats["created"] += 1
        for event_id in alert["event_ids"]:
            self.storage.execute(
                "INSERT OR IGNORE INTO incident_events (incident_id, event_id) VALUES (?, ?)",
                (incident_id, event_id),
            )
        incident = self.storage.query_one("SELECT * FROM incidents WHERE id=?", (incident_id,))
        if self.notifier:
            try:
                self.notifier(incident, is_new)
            except Exception:  # уведомление не должно ронять конвейер
                pass
        return incident

    def set_status(self, incident_id, status, comment=None):
        if status not in STATUSES:
            raise ValueError("unknown status")
        self.storage.execute(
            "UPDATE incidents SET status=?, comment=COALESCE(?, comment), updated_at=? WHERE id=?",
            (status, comment, iso(utcnow()), incident_id),
        )
