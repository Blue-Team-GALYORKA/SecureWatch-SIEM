"""Asset Resolution — привязка события к активу (хосту) из реестра активов.

Если хост встречается впервые, актив создаётся автоматически с критичностью medium;
аналитик потом может поменять критичность и владельца в интерфейсе.
"""

import ipaddress
import json

from ..storage import Storage, iso, utcnow


class AssetResolver:
    def __init__(self, storage: Storage):
        self.storage = storage
        self._cache = {}  # hostname -> asset
        self._ip_map = None  # ip -> asset (строится лениво)
        self.stats = {"resolved": 0, "created": 0}

    def _by_hostname(self, hostname):
        if hostname in self._cache:
            return self._cache[hostname]
        asset = self.storage.query_one("SELECT * FROM assets WHERE hostname=?", (hostname,))
        if asset:
            asset["ips"] = json.loads(asset["ips"])
            self._cache[hostname] = asset
        return asset

    def _by_ip(self, ip):
        if self._ip_map is None:
            self._ip_map = {}
            for asset in self.storage.query("SELECT id, hostname, ips FROM assets"):
                for known_ip in json.loads(asset["ips"]):
                    self._ip_map[known_ip] = asset
        return self._ip_map.get(ip)

    def invalidate(self):
        self._cache.clear()
        self._ip_map = None

    def remember_ips(self, hostname, ips, os_name=None):
        """Агент сообщает свои IP и ОС — сохраняем их в карточке актива."""
        asset = self.resolve_host(hostname)
        if not asset:
            return
        clean = []
        for ip in ips or []:
            try:
                clean.append(str(ipaddress.ip_address(str(ip))))
            except ValueError:
                continue
        merged = sorted(set(asset["ips"]) | set(clean))[:32]
        self.storage.execute("UPDATE assets SET ips=?, os=COALESCE(?, os) WHERE id=?",
                             (json.dumps(merged), (os_name or None) and os_name[:100], asset["id"]))
        self.invalidate()

    def resolve_host(self, hostname):
        if not hostname:
            return None
        hostname = hostname.lower()[:100]
        asset = self._by_hostname(hostname)
        now = iso(utcnow())
        if asset is None:
            asset_id = self.storage.execute(
                "INSERT OR IGNORE INTO assets (hostname, first_seen, last_seen) VALUES (?, ?, ?)",
                (hostname, now, now))
            self.stats["created"] += 1
            asset = self._by_hostname(hostname) or {"id": asset_id, "hostname": hostname, "ips": [],
                                                   "criticality": "medium"}
        return asset

    def resolve(self, event):
        asset = self.resolve_host(event.get("host"))
        if asset:
            event["asset_id"] = asset["id"]
            event["asset_criticality"] = asset["criticality"]
            self.storage.execute("UPDATE assets SET last_seen=? WHERE id=?", (iso(utcnow()), asset["id"]))
            self.stats["resolved"] += 1
        # если источник атаки — тоже наш актив, отметим это
        src_ip = event.get("src_ip")
        if src_ip:
            src_asset = self._by_ip(src_ip)
            if src_asset:
                event["src_asset"] = src_asset["hostname"]
        return event
