"""Корреляция — центральный блок схемы (шестерёнка).

Правила берутся из базы знаний вендора (knowledge/rules/*.yaml). Поддерживаются три типа:

single     — одно событие, подходящее под filter, сразу даёт срабатывание
             (например, очистка журнала или обращение к IP из списка IoC);
threshold  — не меньше threshold событий под filter за window секунд в одной группе group_by
             (например, 5 неудачных входов с одного IP). Опция distinct: считать
             не события, а разные значения поля (например, разных пользователей — password spraying);
sequence   — цепочка шагов steps в пределах window (например, серия неудачных входов,
             а затем успешный вход с того же IP).

Фильтр — это словарь «поле: условие». Условие может быть:
    значением        status: failure
    списком          action: [create, add_to_group]   (любое из)
    оператором       {in: [...]}, {not_in: [...]}, {contains: x}, {regex: "..."},
                     {exists: true}, {ne: x}, {gte: n}, {lte: n}
Для поля tags простое значение означает «тег присутствует».
"""

import re
from collections import deque
from datetime import datetime, timezone

MAX_STATES_PER_RULE = 10000


def _ts(event):
    try:
        return datetime.fromisoformat(event["time"]).timestamp()
    except (KeyError, ValueError, TypeError):
        return 0.0


_regex_cache = {}


def _regex(pattern):
    if pattern not in _regex_cache:
        _regex_cache[pattern] = re.compile(pattern, re.I)
    return _regex_cache[pattern]


def match_condition(value, cond):
    if isinstance(cond, dict):
        for op, arg in cond.items():
            if op == "in" and value not in arg:
                return False
            if op == "not_in" and value in arg:
                return False
            if op == "ne" and value == arg:
                return False
            if op == "exists" and (value not in (None, "", [])) != bool(arg):
                return False
            if op == "contains":
                if value is None or (arg not in value if isinstance(value, (list, str)) else True):
                    return False
            if op == "regex" and (value is None or not _regex(str(arg)).search(str(value))):
                return False
            if op in ("gte", "lte"):
                try:
                    number = float(value)
                except (TypeError, ValueError):
                    return False
                if (op == "gte" and number < float(arg)) or (op == "lte" and number > float(arg)):
                    return False
        return True
    if isinstance(cond, list):
        if isinstance(value, list):
            return any(c in value for c in cond)
        return value in cond or str(value) in [str(c) for c in cond]
    if isinstance(value, list):  # tags
        return cond in value
    return value == cond or (value is not None and str(value) == str(cond))


STEP_OPTIONS = {"min_count", "name"}


def step_filter(step):
    """Шаг sequence: либо {filter: {...}, min_count: N}, либо сам фильтр + min_count."""
    if isinstance(step.get("filter"), dict):
        return step["filter"]
    return {k: v for k, v in step.items() if k not in STEP_OPTIONS}


def match_filter(flt, event):
    return all(match_condition(event.get(field), cond) for field, cond in (flt or {}).items())


class CorrelationEngine:
    def __init__(self, knowledge):
        self.knowledge = knowledge
        self._th_state = {}  # (rule_id, key) -> deque[(ts, count, event_id, distinct)]
        self._seq_state = {}   # (rule_id, key) -> state
        self.stats = {"checked": 0, "alerts": 0}

    def reset(self):
        self._th_state.clear()
        self._seq_state.clear()

    @staticmethod
    def _group(rule, event):
        fields = rule.get("group_by") or []
        values = tuple(event.get(f) for f in fields)
        if any(v in (None, "") for v in values):
            return None
        return values

    def process(self, event):
        """Проверяет событие всеми правилами, возвращает список срабатываний (alerts)."""
        self.stats["checked"] += 1
        alerts = []
        for rule in self.knowledge.rules:
            if not rule.get("enabled", True):
                continue
            handler = getattr(self, f"_{rule['type']}")
            alert = handler(rule, event)
            if alert:
                alerts.append(alert)
        self.stats["alerts"] += len(alerts)
        return alerts

    @staticmethod
    def _alert(rule, key, events_ids, first, last, count, sample):
        group = dict(zip(rule.get("group_by") or [], key or ()))
        return {
            "rule": rule,
            "group": group,
            "group_key": "|".join(f"{k}={v}" for k, v in group.items()) or f"event={sample.get('id')}",
            "event_ids": [i for i in events_ids if i is not None],
            "first_seen": datetime.fromtimestamp(first, timezone.utc).isoformat(timespec="seconds") if first else sample["time"],
            "last_seen": datetime.fromtimestamp(last, timezone.utc).isoformat(timespec="seconds") if last else sample["time"],
            "count": count,
            "event": sample,
        }

    def _prune(self, store, rule_id):
        keys = [k for k in store if k[0] == rule_id]
        if len(keys) > MAX_STATES_PER_RULE:
            for k in keys[: len(keys) - MAX_STATES_PER_RULE]:
                store.pop(k, None)

    # ---------- single ----------
    def _single(self, rule, event):
        if not match_filter(rule["filter"], event):
            return None
        key = self._group(rule, event) if rule.get("group_by") else ()
        if key is None:
            key = ()
        ts = _ts(event)
        return self._alert(rule, key, [event.get("id")], ts, ts, event.get("count", 1), event)

    # ---------- threshold ----------
    def _threshold(self, rule, event):
        if not match_filter(rule["filter"], event):
            return None
        key = self._group(rule, event)
        if key is None:
            return None
        ts, window = _ts(event), rule["window"]
        state = self._th_state.setdefault((rule["id"], key), deque())
        distinct_field = rule.get("distinct")
        state.append((ts, event.get("count", 1), event.get("id"), event.get(distinct_field) if distinct_field else None))
        while state and ts - state[0][0] > window:
            state.popleft()
        if distinct_field:
            value = len({d for *_, d in state if d is not None})
        else:
            value = sum(c for _, c, _, _ in state)
        if value < int(rule["threshold"]):
            if len(state) == 1:
                self._prune(self._th_state, rule["id"])
            return None
        alert = self._alert(rule, key, [i for _, _, i, _ in state], state[0][0], ts, value, event)
        del self._th_state[(rule["id"], key)]
        return alert

    # ---------- sequence ----------
    def _sequence(self, rule, event):
        steps, window = rule["steps"], rule["window"]
        key = self._group(rule, event)
        if key is None:
            return None
        ts = _ts(event)
        state_key = (rule["id"], key)
        state = self._seq_state.get(state_key)
        if state and state["step"] > 0 and ts - state["last"] > window:
            state = None
            self._seq_state.pop(state_key, None)

        first = steps[0]
        if match_filter(step_filter(first), event):
            if state is None:
                state = {"step": 0, "buf": deque(), "events": [], "count": 0, "last": ts, "start": ts}
                self._seq_state[state_key] = state
                self._prune(self._seq_state, rule["id"])
            state["buf"].append((ts, event.get("count", 1), event.get("id")))
            while state["buf"] and ts - state["buf"][0][0] > window:
                state["buf"].popleft()
            if state["step"] == 0:
                if sum(c for _, c, _ in state["buf"]) >= int(first.get("min_count", 1)):
                    state.update(step=1, count=0, last=ts, start=state["buf"][0][0],
                                 events=[i for *_, i in state["buf"]])
            else:
                state["events"].append(event.get("id"))
                state["last"] = ts
            return None

        if not state or state["step"] == 0:
            return None
        step = steps[state["step"]]
        if not match_filter(step_filter(step), event):
            return None
        state["count"] += event.get("count", 1)
        state["events"].append(event.get("id"))
        if state["count"] < int(step.get("min_count", 1)):
            return None
        state.update(step=state["step"] + 1, count=0, last=ts)
        if state["step"] < len(steps):
            return None
        self._seq_state.pop(state_key, None)
        total = len(state["events"])
        return self._alert(rule, key, state["events"], state["start"], ts, total, event)
