"""Конвейер обработки событий — склеивает сервисы в порядке схемы:

  MP agent → Receiver.S → Normalization.S → Aggregator.S → Asset Resolution
           → Enricher.S (обогащает и сохраняет) → Корреляция → Инциденты → Frontend.S
                                         ↑
                          база знаний вендора (правила, IoC)
"""

import logging
import queue
import threading
import time

from .config import Settings
from .knowledge import KnowledgeBase
from .services import (Aggregator, AssetResolver, CorrelationEngine, Enricher, IncidentManager,
                       Normalizer, Receiver)
from .storage import Storage

log = logging.getLogger("siem.pipeline")


class Pipeline:
    def __init__(self, settings: Settings, storage: Storage | None = None):
        self.settings = settings
        self.storage = storage or Storage(settings.database_path)
        self.knowledge = KnowledgeBase(settings.knowledge_dir)
        self.receiver = Receiver()
        self.normalizer = Normalizer(settings.timezone)
        self.aggregator = Aggregator(settings.aggregation_window)
        self.assets = AssetResolver(self.storage)
        self.enricher = Enricher(self.storage, self.knowledge, settings.timezone, settings.work_hours)
        self.correlation = CorrelationEngine(self.knowledge)
        self.incidents = IncidentManager(self.storage, notifier=self._log_incident)
        self._stop = threading.Event()
        self._thread = None
        self._last_purge = 0.0
        self.errors = 0

    @staticmethod
    def _log_incident(incident, is_new):
        if is_new:
            log.warning("ИНЦИДЕНТ #%s [%s] %s", incident["id"], incident["severity"], incident["title"])

    # ---------- обработка ----------
    def _downstream(self, events):
        """Всё, что идёт после агрегатора."""
        for event in events:
            try:
                self.assets.resolve(event)
                self.enricher.enrich(event)
                self.enricher.save(event)
                for alert in self.correlation.process(event):
                    self.incidents.handle(alert)
            except Exception:
                self.errors += 1
                log.exception("Ошибка обработки события")

    def process_record(self, record):
        event = self.normalizer.normalize(record)
        self._downstream(self.aggregator.add(event))

    def flush(self, force=False):
        self._downstream(self.aggregator.flush(force=force))

    def drain(self):
        """Синхронно обработать всё из очереди (для тестов и симулятора)."""
        while True:
            try:
                record = self.receiver.queue.get_nowait()
            except queue.Empty:
                break
            self.process_record(record)
        self.flush(force=True)

    # ---------- фоновый поток ----------
    def _run(self):
        log.info("Конвейер запущен: правил %d, IoC %d", len(self.knowledge.rules),
                 len(self.knowledge.ioc_ips) + len(self.knowledge.ioc_networks))
        while not self._stop.is_set():
            try:
                record = self.receiver.queue.get(timeout=0.5)
                self.process_record(record)
            except queue.Empty:
                pass
            except Exception:
                self.errors += 1
                log.exception("Ошибка конвейера")
            self.flush()
            now = time.monotonic()
            if now - self._last_purge > 3600:
                self._last_purge = now
                removed = self.storage.purge_old_events(self.settings.retention_days)
                if removed:
                    log.info("Удалено устаревших событий: %d", removed)
        self.flush(force=True)

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="siem-pipeline", daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)

    def reload_knowledge(self):
        result = self.knowledge.reload()
        self.correlation.reset()
        return result

    # ---------- для страницы Data flow ----------
    def flow_stats(self):
        return [
            {"name": "MP agent / syslog", "stage": "источники", "value": self.receiver.stats["accepted"]},
            {"name": "Receiver.S", "stage": "принять логи", "value": self.receiver.stats["accepted"],
             "extra": f"в очереди: {self.receiver.queue.qsize()}"},
            {"name": "Normalization.S", "stage": "парсинг", "value": self.normalizer.stats["parsed"],
             "extra": f"не распознано: {self.normalizer.stats['unparsed']}"},
            {"name": "Aggregator.S", "stage": "склейка событий", "value": self.aggregator.stats["out"],
             "extra": f"на входе: {self.aggregator.stats['in']}"},
            {"name": "Asset Resolution", "stage": "активы", "value": self.assets.stats["resolved"],
             "extra": f"новых активов: {self.assets.stats['created']}"},
            {"name": "Enricher.S", "stage": "обогащение и сохранение", "value": self.enricher.stats["saved"],
             "extra": f"совпадений IoC: {self.enricher.stats['ioc_hits']}"},
            {"name": "Корреляция", "stage": "правила вендора", "value": self.correlation.stats["alerts"],
             "extra": f"правил: {len(self.knowledge.rules)}"},
            {"name": "Инциденты", "stage": "сообщение об инциденте", "value": self.incidents.stats["created"],
             "extra": f"обновлено: {self.incidents.stats['updated']}"},
        ]
