"""Frontend.S + API приёма — веб-интерфейс аналитика (на схеме «MP core: польз. интерфейс»)."""

import contextlib
import json
import logging
import math
import secrets
from pathlib import Path

from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.middleware.sessions import SessionMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, PlainTextResponse, RedirectResponse
from starlette.routing import Mount, Route
from starlette.staticfiles import StaticFiles
from starlette.templating import Jinja2Templates

from .config import BASE_DIR, settings
from .pipeline import Pipeline
from .security import (LoginLimiter, check_csrf, csrf_token, hash_password, new_agent_token,
                       token_hash, verify_password)
from .services.incidents import SEVERITY_ORDER, STATUS_LABELS, STATUSES
from .storage import iso, utcnow
from .syslog_listener import SyslogListener

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("siem.web")

MAX_INGEST_BYTES = 2 * 1024 * 1024
CRITICALITIES = ("low", "medium", "high", "critical")
PAGE_SIZE = 50

templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
templates.env.globals.update(STATUS_LABELS=STATUS_LABELS, STATUSES=STATUSES, CRITICALITIES=CRITICALITIES)
templates.env.filters["short_time"] = lambda v: (v or "").replace("T", " ")[:19]
templates.env.filters["pretty_json"] = lambda v: json.dumps(v, ensure_ascii=False, indent=2, default=str)

pipeline: Pipeline | None = None
syslog: SyslogListener | None = None
limiter = LoginLimiter()

if not settings.secret_key or len(settings.secret_key) < 32:
    log.warning("SECRET_KEY не задан или короче 32 символов — сгенерирован временный, сессии сбросятся при перезапуске")
    settings.secret_key = secrets.token_urlsafe(48)

_admin_password = settings.admin_password
if not _admin_password:
    _admin_password = secrets.token_urlsafe(12)
    log.warning("SIEM_ADMIN_PASSWORD не задан. Временный пароль для %s: %s", settings.admin_user, _admin_password)
ADMIN_PASSWORD_HASH = hash_password(_admin_password)
del _admin_password


# ---------- помощники ----------
def client_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def render(request, name, status_code=200, **context):
    context.update(request=request, user=request.session.get("user"), csrf=csrf_token(request.session))
    return templates.TemplateResponse(request, name, context, status_code=status_code)


def login_required(handler):
    async def wrapper(request: Request):
        if not request.session.get("user"):
            return RedirectResponse("/login", status_code=303)
        if request.method == "POST":
            form = await request.form()
            if not check_csrf(request.session, form.get("csrf")):
                return PlainTextResponse("CSRF token invalid", status_code=403)
            request.state.form = form
        return await handler(request)
    wrapper.__name__ = handler.__name__
    return wrapper


def int_param(value, default=0):
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return default


# ---------- вход ----------
async def login_page(request: Request):
    if request.method == "GET":
        return render(request, "login.html", error=None)
    ip = client_ip(request)
    if limiter.blocked(ip):
        return render(request, "login.html", 429, error="Слишком много попыток. Подождите 5 минут.")
    form = await request.form()
    if not check_csrf(request.session, form.get("csrf")):
        return render(request, "login.html", 403, error="Сессия устарела, обновите страницу.")
    username, password = str(form.get("username", "")), str(form.get("password", ""))
    password_ok = verify_password(password, ADMIN_PASSWORD_HASH)
    if not (secrets.compare_digest(username, settings.admin_user) and password_ok):
        limiter.fail(ip)
        log.warning("Неудачный вход в SIEM: %r с %s", username[:50], ip)
        return render(request, "login.html", 401, error="Неверное имя пользователя или пароль")
    limiter.reset(ip)
    request.session.clear()
    request.session["user"] = settings.admin_user
    return RedirectResponse("/dashboard", status_code=303)


@login_required
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", status_code=303)


async def index(request: Request):
    return RedirectResponse("/dashboard" if request.session.get("user") else "/login", status_code=303)


# ---------- дашборд ----------
@login_required
async def dashboard(request: Request):
    stats = pipeline.storage.stats()
    latest = pipeline.storage.query(
        "SELECT * FROM incidents WHERE status IN ('new','in_progress') ORDER BY last_seen DESC LIMIT 8")
    latest.sort(key=lambda i: -SEVERITY_ORDER.get(i["severity"], 0))
    return render(request, "dashboard.html", stats=stats, flow=pipeline.flow_stats(), incidents=latest,
                  knowledge=pipeline.knowledge)


# ---------- события ----------
@login_required
async def events_page(request: Request):
    q = request.query_params
    filters = {k: q.get(k, "").strip()[:100] for k in ("text", "host", "src_ip", "category", "status")}
    page = max(1, int_param(q.get("page"), 1))
    rows, total = pipeline.storage.search_events(**filters, limit=PAGE_SIZE, offset=(page - 1) * PAGE_SIZE)
    categories = [r["category"] for r in pipeline.storage.query("SELECT DISTINCT category FROM events ORDER BY 1")]
    return render(request, "events.html", events=rows, total=total, filters=filters, page=page,
                  pages=max(1, math.ceil(total / PAGE_SIZE)), categories=categories)


@login_required
async def event_detail(request: Request):
    event = pipeline.storage.get_event(int_param(request.path_params["event_id"]))
    if not event:
        return PlainTextResponse("Событие не найдено", status_code=404)
    linked = pipeline.storage.query(
        "SELECT i.id, i.title, i.severity FROM incidents i JOIN incident_events ie ON ie.incident_id=i.id "
        "WHERE ie.event_id=?", (event["id"],))
    return render(request, "event_detail.html", event=event, incidents=linked)


# ---------- инциденты ----------
@login_required
async def incidents_page(request: Request):
    status = request.query_params.get("status", "open")
    if status == "open":
        rows = pipeline.storage.query(
            "SELECT * FROM incidents WHERE status IN ('new','in_progress') ORDER BY last_seen DESC LIMIT 500")
    elif status in STATUSES:
        rows = pipeline.storage.query("SELECT * FROM incidents WHERE status=? ORDER BY last_seen DESC LIMIT 500", (status,))
    else:
        status = "all"
        rows = pipeline.storage.query("SELECT * FROM incidents ORDER BY last_seen DESC LIMIT 500")
    return render(request, "incidents.html", incidents=rows, status=status)


@login_required
async def incident_detail(request: Request):
    incident_id = int_param(request.path_params["incident_id"])
    if request.method == "POST":
        form = request.state.form
        status = form.get("status")
        if status in STATUSES:
            comment = str(form.get("comment", "")).strip()[:2000] or None
            pipeline.incidents.set_status(incident_id, status, comment)
        return RedirectResponse(f"/incidents/{incident_id}", status_code=303)
    incident = pipeline.storage.query_one("SELECT * FROM incidents WHERE id=?", (incident_id,))
    if not incident:
        return PlainTextResponse("Инцидент не найден", status_code=404)
    events = [pipeline.storage._decode_event(e) for e in pipeline.storage.query(
        "SELECT e.* FROM events e JOIN incident_events ie ON ie.event_id=e.id WHERE ie.incident_id=? "
        "ORDER BY e.time LIMIT 200", (incident_id,))]
    rule = next((r for r in pipeline.knowledge.rules if r["id"] == incident["rule_id"]), None)
    return render(request, "incident_detail.html", incident=incident, events=events, rule=rule)


# ---------- активы ----------
@login_required
async def assets_page(request: Request):
    if request.method == "POST":
        form = request.state.form
        criticality = form.get("criticality")
        if criticality in CRITICALITIES:
            pipeline.storage.execute(
                "UPDATE assets SET criticality=?, owner=? WHERE id=?",
                (criticality, str(form.get("owner", "")).strip()[:100] or None, int_param(form.get("asset_id"))))
            pipeline.assets.invalidate()
        return RedirectResponse("/assets", status_code=303)
    rows = pipeline.storage.query(
        "SELECT a.*, (SELECT COALESCE(SUM(count),0) FROM events e WHERE e.asset_id=a.id) AS events, "
        "(SELECT COUNT(*) FROM incidents i WHERE i.host=a.hostname AND i.status IN ('new','in_progress')) AS open_incidents "
        "FROM assets a ORDER BY a.last_seen DESC")
    for row in rows:
        row["ips"] = json.loads(row["ips"])
    return render(request, "assets.html", assets=rows)


# ---------- правила (база знаний вендора) ----------
@login_required
async def rules_page(request: Request):
    message = None
    if request.method == "POST":
        result = pipeline.reload_knowledge()
        message = f"База знаний обновлена: правил {result['rules']}, IoC {result['ioc']}, ошибок {len(result['errors'])}"
        log.info(message)
    counts = {r["rule_id"]: r["n"] for r in pipeline.storage.query(
        "SELECT rule_id, COUNT(*) AS n FROM incidents GROUP BY rule_id")}
    return render(request, "rules.html", knowledge=pipeline.knowledge, counts=counts, message=message)


# ---------- агенты ----------
@login_required
async def agents_page(request: Request):
    new_token = None
    if request.method == "POST":
        form = request.state.form
        action = form.get("action")
        if action == "create":
            name = str(form.get("name", "")).strip()[:100] or "agent"
            new_token = new_agent_token()
            pipeline.storage.execute(
                "INSERT INTO agents (name, token_hash, created_at) VALUES (?, ?, ?)",
                (name, token_hash(new_token), iso(utcnow())))
        elif action == "toggle":
            pipeline.storage.execute("UPDATE agents SET enabled = 1 - enabled WHERE id=?", (int_param(form.get("agent_id")),))
        if not new_token:
            return RedirectResponse("/agents", status_code=303)
    agents = pipeline.storage.query("SELECT * FROM agents ORDER BY id DESC")
    server = f"{request.url.scheme}://{request.url.netloc}"
    return render(request, "agents.html", agents=agents, new_token=new_token, server=server)


# ---------- API для агентов (Receiver.S) ----------
async def api_ingest(request: Request):
    auth = request.headers.get("authorization", "")
    scheme, _, token = auth.partition(" ")
    if scheme.lower() != "bearer" or not token or len(token) > 128:
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    agent = pipeline.storage.query_one("SELECT * FROM agents WHERE token_hash=? AND enabled=1", (token_hash(token),))
    if not agent:
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    if int_param(request.headers.get("content-length"), 0) > MAX_INGEST_BYTES:
        return JSONResponse({"error": "payload too large"}, status_code=413)
    body = await request.body()
    if len(body) > MAX_INGEST_BYTES:
        return JSONResponse({"error": "payload too large"}, status_code=413)
    try:
        payload = json.loads(body)
        host = str(payload.get("host") or agent["name"])[:100]
        info = payload.get("agent_info") or {}
        if isinstance(info, dict) and isinstance(info.get("ips"), list):
            pipeline.assets.remember_ips(host, info["ips"][:32], str(info.get("os") or "")[:100] or None)
        accepted = pipeline.receiver.accept(payload.get("records") or [], host=host, source=f"agent:{agent['name']}")
    except (ValueError, AttributeError, TypeError) as exc:
        return JSONResponse({"error": str(exc)[:200]}, status_code=400)
    except OverflowError:
        return JSONResponse({"error": "busy, retry later"}, status_code=503)
    pipeline.storage.execute(
        "UPDATE agents SET last_seen=?, last_ip=?, events_received=events_received+? WHERE id=?",
        (iso(utcnow()), client_ip(request), accepted, agent["id"]))
    return JSONResponse({"accepted": accepted})


async def api_health(request: Request):
    return JSONResponse({"status": "ok", "queue": pipeline.receiver.queue.qsize(), "errors": pipeline.errors})


# ---------- приложение ----------
@contextlib.asynccontextmanager
async def lifespan(app):
    global pipeline, syslog
    pipeline = Pipeline(settings)
    pipeline.start()
    if settings.syslog_port:
        syslog = SyslogListener(pipeline.receiver, settings.syslog_port)
        try:
            syslog.start()
        except OSError as exc:
            log.error("Не удалось открыть syslog-порт %s: %s", settings.syslog_port, exc)
            syslog = None
    yield
    if syslog:
        syslog.stop()
    pipeline.stop()


class SecurityHeaders:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        async def send_with_headers(message):
            if message["type"] == "http.response.start":
                headers = message.setdefault("headers", [])
                headers += [
                    (b"x-content-type-options", b"nosniff"),
                    (b"x-frame-options", b"DENY"),
                    (b"referrer-policy", b"same-origin"),
                    (b"content-security-policy",
                     b"default-src 'self'; style-src 'self'; script-src 'self'; frame-ancestors 'none'; form-action 'self'"),
                ]
            await send(message)
        await self.app(scope, receive, send_with_headers)


routes = [
    Route("/", index),
    Route("/login", login_page, methods=["GET", "POST"]),
    Route("/logout", logout, methods=["POST"]),
    Route("/dashboard", dashboard),
    Route("/events", events_page),
    Route("/events/{event_id:int}", event_detail),
    Route("/incidents", incidents_page),
    Route("/incidents/{incident_id:int}", incident_detail, methods=["GET", "POST"]),
    Route("/assets", assets_page, methods=["GET", "POST"]),
    Route("/rules", rules_page, methods=["GET", "POST"]),
    Route("/agents", agents_page, methods=["GET", "POST"]),
    Route("/api/v1/ingest", api_ingest, methods=["POST"]),
    Route("/api/v1/health", api_health),
    Mount("/static", StaticFiles(directory=str(Path(BASE_DIR) / "static")), name="static"),
]

app = Starlette(
    routes=routes,
    lifespan=lifespan,
    middleware=[
        Middleware(SecurityHeaders),
        Middleware(SessionMiddleware, secret_key=settings.secret_key, session_cookie="siem_session",
                   max_age=8 * 3600, same_site="strict", https_only=settings.cookie_secure),
    ],
)
