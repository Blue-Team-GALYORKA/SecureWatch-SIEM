"""Точка входа: uvicorn app:app"""
from siem.web import app  # noqa: F401
