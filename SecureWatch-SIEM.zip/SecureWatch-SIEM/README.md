# SecureWatch SIEM

Учебная SIEM-система команды **Blue Team GALYORKA**, сделанная по схеме потоков данных
MaxPatrol SIEM (Data Flow). Это отдельный модуль проекта
[SecureWatch](https://github.com/Blue-Team-GALYORKA/secure-watch-): он собирает журналы с хостов,
нормализует их, склеивает, обогащает, коррелирует по правилам и показывает аналитику инциденты.

> Проект учебный. Он повторяет архитектуру промышленной SIEM, но не является её копией
> и не предназначен для защиты реальной инфраструктуры.

## Схема

Исходная схема с доски: [`docs/dataflow-whiteboard.jpg`](docs/dataflow-whiteboard.jpg).

```mermaid
flowchart LR
    subgraph Hosts["Хосты (us.1, us.2, …)"]
        A1[MP agent] 
        A2[MP agent]
        S[syslog UDP]
    end
    subgraph ASOI["АСОИ — контур SIEM"]
        R[Receiver.S<br/>принять логи] --> N[Normalization.S<br/>парсинг]
        N --> AG[Aggregator.S<br/>склеить события]
        AG --> AR[Asset Resolution<br/>активы]
        AR --> E[Enricher.S<br/>обогатить и сохранить]
        E --> DB[(хранилище<br/>событий)]
        E --> C{{Корреляция}}
        V[база знаний вендора<br/>правила + IoC] --> C
        V --> E
        C --> I[сообщение<br/>об инциденте]
        I --> F[Frontend.S]
        DB --> F
    end
    A1 --> R
    A2 --> R
    S --> R
    F --> UI[MP core:<br/>интерфейс аналитика]
```

| Блок на схеме | Где в коде | Что делает |
|---|---|---|
| MP agent | `agent/mp_agent.py` | Читает новые строки журналов на хосте и отправляет пачками по HTTP с токеном. Помнит позицию чтения и переживает ротацию логов |
| Receiver.S | `siem/services/receiver.py`, `siem/syslog_listener.py`, `POST /api/v1/ingest` | Принимает записи от агентов и по syslog, проверяет размеры, кладёт в очередь |
| Normalization.S | `siem/services/normalization.py` | Разбирает syslog (RFC 3164/5424), журналы sshd/sudo/useradd, access-логи nginx/apache, события Windows (JSON) и приводит их к единой схеме |
| Aggregator.S | `siem/services/aggregator.py` | Склеивает одинаковые события за окно в одно с полем `count` |
| Asset Resolution | `siem/services/asset_resolution.py` | Привязывает событие к активу и автоматически заводит новые активы |
| Enricher.S | `siem/services/enricher.py` | Добавляет теги: внутренний или внешний адрес, IoC, критичный актив, привилегированный пользователь, нерабочее время. Сохраняет событие |
| Корреляция | `siem/services/correlation.py` | Движок правил трёх типов: `single`, `threshold`, `sequence` |
| пополнение инф. вендора | `knowledge/rules/*.yaml`, `knowledge/ioc/*.txt`, `siem/knowledge.py` | Правила и индикаторы компрометации. Обновляются без перезапуска |
| сообщение об инциденте | `siem/services/incidents.py` | Создаёт инциденты и не плодит дубли, пока инцидент открыт |
| Frontend.S / MP core | `siem/web.py`, `templates/` | Веб-интерфейс: обзор с Data flow, события, инциденты, активы, правила, агенты |

## Быстрый старт

### Docker

```bash
cp .env.example .env          # впишите SECRET_KEY и SIEM_ADMIN_PASSWORD
mkdir -p data && sudo chown 10001:10001 data   # контейнер работает от пользователя uid 10001
docker compose up -d --build
```

Откройте http://127.0.0.1:8080 и войдите под `admin`.

### Без Docker

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env          # впишите SECRET_KEY и SIEM_ADMIN_PASSWORD
uvicorn app:app --host 127.0.0.1 --port 8080
```

## Демонстрация

1. В разделе **Агенты** создайте агента и скопируйте токен (он показывается один раз).
2. Запустите генератор атак:
   ```bash
   python3 tools/simulate_attack.py --server http://127.0.0.1:8080 --token swa_...
   ```
   Он отправит фоновую активность и семь сценариев: подбор пароля с успешным входом,
   password spraying, создание пользователя с выдачей прав администратора и опасными командами через sudo,
   веб-сканирование и SQL-инъекцию, обращение к адресу из IoC и атаку на контроллер домена
   с очисткой журнала. Через несколько секунд появится около 20 инцидентов.
3. На **Обзоре** видно, сколько событий прошло через каждый блок схемы.

### Настоящий хост

```bash
sudo python3 agent/mp_agent.py --server http://SIEM:8080 --token swa_... \
    --file /var/log/auth.log --file /var/log/nginx/access.log:access
```

Агенту нужен только Python 3.10+, без внешних зависимостей. Чтобы прочитать уже накопленный журнал целиком, добавьте `--from-start`.

Syslog можно слать напрямую на UDP-порт `SIEM_SYSLOG_PORT`, например из rsyslog: `*.* @SIEM:5514`.

События Windows принимаются как JSON, по одному на строку, с полями `EventID`, `Computer`,
`TimeCreated`, `TargetUserName`, `IpAddress` и т. д. Например, их можно выгрузить через PowerShell
`Get-WinEvent … | ConvertTo-Json -Compress` и подать агенту как файл с форматом `:windows`.

## Правила корреляции

Правила лежат в `knowledge/rules/*.yaml`. После правки нажмите **Правила → Обновить базу знаний**.

```yaml
- id: SW-AUTH-001                 # уникальный идентификатор
  name: Подбор пароля (brute force)
  title: "Подбор пароля к {host} с {src_ip}: {count} неудачных попыток"
  type: threshold                 # single | threshold | sequence
  severity: high                  # low | medium | high | critical
  mitre: T1110.001
  filter: {category: auth, action: login, status: failure}
  group_by: [src_ip, host]        # что считается «одной атакой»
  threshold: 5                    # сколько событий…
  window: 120                     # …за сколько секунд
  # distinct: subject_user        # считать разные значения поля, а не события
```

Для `sequence` вместо `filter` задаётся список шагов `steps`, у каждого шага можно указать `min_count`.
Условия в фильтре: точное значение, список значений или операторы `in`, `not_in`, `contains`, `regex`,
`exists`, `ne`, `gte`, `lte`. Для поля `tags` простое значение означает «тег есть».

Индикаторы компрометации кладутся в `knowledge/ioc/*.txt`: один IP или подсеть на строку.

| Правило | Что ловит |
|---|---|
| SW-AUTH-001…006 | Подбор пароля, успешный вход после подбора, password spraying, вход администратора извне, вход в нерабочее время, блокировка учётной записи |
| SW-ACC-001…003 | Новая учётная запись, добавление в группу администраторов и связка «создал и сразу выдал права» |
| SW-SYS-001…002 | Очистка журнала, установка службы |
| SW-PROC-001 | Опасные команды через sudo: reverse shell, чтение `/etc/shadow`, `curl … \| sh` |
| SW-TI-001 | Активность адреса из IoC |
| SW-WEB-001…002 | SQLi, XSS, обход каталогов, сканеры, перебор путей |

## Схема нормализованного события

`time`, `host`, `category` (auth / account / process / web / system / other), `action`,
`status` (success / failure / info), `importance`, `src_ip`, `dst_ip`, `subject_user`, `object`,
`msg`, `count`, `asset_id`, `tags` и исходная строка `raw`. Дополнительные поля, например `attack`,
`http_status` и `ioc`, хранятся в `data`.

## Тесты

```bash
python -m unittest discover -s tests -v
```

## Безопасность

- Агенты аутентифицируются токенами. В базе хранится только SHA-256 токена, агента можно отключить.
- Вход аналитика: пароль хешируется scrypt, неудачные попытки ограничены (5 за 5 минут с одного IP).
- Сессии: cookie `SameSite=Strict`, все формы с CSRF-токеном. Заголовки CSP, `X-Frame-Options` и `nosniff`.
- Ограничения на размер: 2 МБ на запрос, 1000 записей в пачке, 8 КБ на строку.
- Syslog по UDP не аутентифицируется, поэтому порт открывайте только во внутренней сети.
- В IoC-списке для демонстрации только адреса из документационных диапазонов RFC 5737.

## Структура

```
agent/mp_agent.py          MP agent
siem/services/             сервисы по схеме: receiver, normalization, aggregator,
                           asset_resolution, enricher, correlation, incidents
siem/pipeline.py           конвейер, соединяющий сервисы
siem/knowledge.py          загрузка базы знаний вендора
siem/web.py                Frontend.S и API
knowledge/                 правила корреляции и IoC
templates/, static/        интерфейс
tools/simulate_attack.py   генератор демо-атак
tests/                     тесты
```
